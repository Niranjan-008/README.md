Welcome to my Slash Mark Virtual Internship repository! This repository contains a collection of machine learning projects that I worked on during my internship with Slash Mark. The program provided me with valuable hands-on experience in various aspects of machine learning, from basic to advanced levels. Below, you will find descriptions of each project I completed as part of this program


