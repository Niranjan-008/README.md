# Slash_Mark_Internship
Online Internship Projects (May 31 - Jun 30)
You can find different tasks in this internships on the corresponding folders.
